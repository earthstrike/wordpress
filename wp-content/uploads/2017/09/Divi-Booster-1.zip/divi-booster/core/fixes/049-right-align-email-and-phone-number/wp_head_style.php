@media only screen and (min-width: 768px) {
	#et-info { float:right !important }
}