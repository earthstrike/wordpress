.et_pb_posts_nav .nav-previous { float: right; }
.et_pb_posts_nav .nav-next { float: left; }
.et_pb_posts_nav .meta-nav { display: none; }
.et_pb_posts_nav .nav-next a:before { content: '← '; }
.et_pb_posts_nav .nav-previous a:after { content: ' →'; }