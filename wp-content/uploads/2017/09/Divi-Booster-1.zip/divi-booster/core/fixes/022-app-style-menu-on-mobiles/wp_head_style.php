@media only screen and ( max-width: 980px ) {
    #main-header .container { 
        width:100%;
        box-sizing:border-box;
        padding-right:30px;
        padding-left:30px;
    }
}