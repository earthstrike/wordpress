header#main-header.et-fixed-header, #main-header{
	-webkit-box-shadow:none !important;
	-moz-box-shadow:none !important;
	box-shadow:none !important;
}