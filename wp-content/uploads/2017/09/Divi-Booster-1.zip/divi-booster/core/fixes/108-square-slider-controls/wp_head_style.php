.et_pb_slider:not(.et_pb_post_slider) .et-pb-controllers a {
    border-radius: 0 !important;
}