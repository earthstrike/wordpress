#top-menu li.current-menu-item > a { color: black !important; }
#top-menu li.current-menu-item > a:hover { color: #2ea3f2 !important; }