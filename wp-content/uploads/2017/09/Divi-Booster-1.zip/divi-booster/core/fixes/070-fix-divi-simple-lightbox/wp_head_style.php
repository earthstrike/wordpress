#top-header { z-index:3 !important; }
#et-secondary-nav .submenu { z-index:100000 !important }