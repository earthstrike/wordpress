#main-header { display:none; }
#page-container { 
	padding-top:0px !important; 
	margin-top:-1px !important 
}
#main-content .container {
    padding-top: 58px !important;
}