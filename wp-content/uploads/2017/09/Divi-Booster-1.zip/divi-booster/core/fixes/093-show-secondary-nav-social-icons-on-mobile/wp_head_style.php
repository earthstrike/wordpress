@media only screen and (max-width: 767px) {
  #et-info .et-social-icons {
    display: block !important;
  }
  #et-info .et-social-icons li { 
    padding-top:12px;
  }
}
