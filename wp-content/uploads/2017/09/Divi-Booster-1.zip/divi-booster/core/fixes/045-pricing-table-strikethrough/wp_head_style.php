.et_pb_pricing li.et_pb_not_available {
	text-decoration: line-through;
}